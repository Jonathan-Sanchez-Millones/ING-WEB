using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABB.Catalogo.Entidades.Core
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string DesCategoria { get; set; }
    }
}
